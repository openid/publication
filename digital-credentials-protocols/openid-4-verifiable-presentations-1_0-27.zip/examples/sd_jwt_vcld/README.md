# Examples for SD-JWT VCLD

These examples were generated from the settings.yml file and 01/specification.yml file using the [SD-JWT reference implementation](https://github.com/openwallet-foundation-labs/sd-jwt-python/tree/main).