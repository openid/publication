Built the XML and HTML using Daniel Fett's docker magic
docker run -v /Users/briancampbell/dev/fapi/other-account/fapi:/data danielfett/markdown2rfc ./oauth-v2-jarm.md
copied oauth-v2-jarm-04.html to oauth-v2-jarm-final.html
edit oauth-v2-jarm-final.html to drop the -04 and say "Status: Final" (diff oauth-v2-jarm-04.html and oauth-v2-jarm-final.html to see specifics)
