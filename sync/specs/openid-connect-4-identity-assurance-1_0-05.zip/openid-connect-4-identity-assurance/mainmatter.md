
{{introduction.md}}

{{scope.md}}

{{claims.md}}

{{representation.md}}

{{requesting.md}}

{{examples.md}}

{{opmetadata.md}}

{{purpose.md}}

# Privacy Consideration {#Privacy}
OP and RP MUST establish a legal basis before exchanging any personally identifiable information. It can be established upfront or in the course of the OpenID process. 

# Security Considerations {#Security}
      
TBD

{{predefined_values.md}}

{{schema.md}}

