
{{introduction.md}}

{{scope.md}}

{{claims.md}}

{{representation.md}}

{{requesting.md}}

{{examples.md}}

{{opmetadata.md}}

# Acknowledgements {#Acknowledgements}
      
The following people at yes.com and partner companies contributed to the concept described in this document: Sven Manz, Waldemar Zimpfer, Willi Wiedergold, Fabian Hoffmann, Daniel Keijsers, Ralf Wagner, Sebastian Ebling, Peter Eisenhofer.
      
I would like to thank Marcus Sanz, Tom Jones, and Jeff Lombardo for their valuable feedback that helped to further shape this specification.
    
{{ianaconsiderations.md}}
    

# Security Considerations {#Security}
      
TBD
    
