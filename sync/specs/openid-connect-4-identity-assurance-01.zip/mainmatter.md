
{{introduction.md}}

{{scope.md}}

{{claims.md}}

{{representation.md}}

{{requesting.md}}

{{examples.md}}

{{opmetadata.md}}

# Acknowledgements {#Acknowledgements}
      
The following people at yes.com and partner companies contributed to the concept described in this document: Lukas Stiebig, Sven Manz, Waldemar Zimpfer, Willi Wiedergold, Fabian Hoffmann, Daniel Keijsers, Ralf Wagner, Sebastian Ebling, Peter Eisenhofer.
      
I would like to thank Marcus Sanz, Tom Jones, Mike Pegman, and Jeff Lombardo for their valuable feedback that helped to further shape this specification. 

# Privacy Consideration {#Privacy}
OP and RP MUST establish a legal basis before exchanging any personally identifiable information.

# Security Considerations {#Security}
      
TBD

{{predefined_values.md}}

