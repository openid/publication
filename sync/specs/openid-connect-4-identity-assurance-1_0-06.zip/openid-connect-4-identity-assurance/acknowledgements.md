# Acknowledgements {#Acknowledgements}
      
The following people at yes.com and partner companies contributed to the concept described in the initial contribution to this specification: Karsten Buch, Lukas Stiebig, Sven Manz, Waldemar Zimpfer, Willi Wiedergold, Fabian Hoffmann, Daniel Keijsers, Ralf Wagner, Sebastian Ebling, Peter Eisenhofer.
      
I would like to thank Sebastian Ebling, Marcos Sanz, Tom Jones, Mike Pegman, 
Michael B. Jones, and Jeff Lombardo for their valuable feedback that helped to evolve this specification. 