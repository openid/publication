__Claim `givenName`__:

 * SHA-256 Hash: `NTDVsbVAwS9AnUVq-_YG_wv0yGD0bv2JstX-AmvN65I`
 * Disclosure:\
`WyIyR0xDNDJzS1F2ZUNmR2ZyeU5STjl3IiwgImdpdmVuTmFtZSIsICJKb2hu`\
`Il0`
 * Contents:
`["2GLC42sKQveCfGfryNRN9w", "givenName", "John"]`


__Claim `familyName`__:

 * SHA-256 Hash: `6BJdQrO24ejTTMsFI-wGiJJmGrbseWc5IwCCp4NAJ0k`
 * Disclosure:\
`WyJlbHVWNU9nM2dTTklJOEVZbnN4QV9BIiwgImZhbWlseU5hbWUiLCAiRG9l`\
`Il0`
 * Contents:
`["eluV5Og3gSNII8EYnsxA_A", "familyName", "Doe"]`


__Claim `birthDate`__:

 * SHA-256 Hash: `ts0pyPntLjD0_NcgNOI3hd_2WjbZw21p2LfqhOC0b-U`
 * Disclosure:\
`WyI2SWo3dE0tYTVpVlBHYm9TNXRtdlZBIiwgImJpcnRoRGF0ZSIsICIxOTc4`\
`LTA3LTE3Il0`
 * Contents:
`["6Ij7tM-a5iVPGboS5tmvVA", "birthDate", "1978-07-17"]`